package com.example.weatherforecast;

//import androidx.appcompat.app.AppCompatActivity;
//
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.format.Time;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

//setToNow()
//import java.sql.Time;

//놀러 가세요


public class MainActivity extends AppCompatActivity {

    private ListView listview;
    TextView text_city;
    List<String>list;
    ArrayAdapter<String> adapter;

    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.action_refresh:
                return true;
            case R.id.action_settings:
                Intent intent2 = new Intent(this, SettingsActivity.class);
                this.startActivity(intent2);
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listview = findViewById(R.id.view_forecast);

        List<String> list = new ArrayList<>();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,list);
        listview.setAdapter(adapter);

        String content;
        FetchWeatherTask weatherTask = new FetchWeatherTask();
        try {
//            String id="1835847";
////            TextView text_city = findViewById(R.id.city);
////            text_city.setText("Seoul");
            SharedPreferences spf = PreferenceManager.getDefaultSharedPreferences(this);
            String id =spf.getString("city","0");
            text_city = findViewById(R.id.city);
            if(id.equals("1835847"))text_city.setText("Seoul");
            else if(id.equals("1835235")) text_city.setText("Daejeon");
            else if(id.equals("1835327")) text_city.setText("Taegu");
            else text_city.setText("Busan");
            content = weatherTask.execute("http://api.openweathermap.org/data/2.5/forecast/daily?id="+id+"&mode=json&units=metric&cnt=7&appid=5fd2f2cde90c1533efb95b19c048a528").get();
//            Log.i("content", content);

            JSONObject jsonObject = new JSONObject((content));
            String city =new JSONObject(jsonObject.getString("city")).getString("name");


            JSONArray datalist = new JSONArray((jsonObject.getString("list")));
            Date currentTime = Calendar.getInstance().getTime();
//            String[] array = new String[7];
            Time dayTime = new Time();
            dayTime.setToNow();
            long dateTime;
            int julianStartDay = Time.getJulianDay(System.currentTimeMillis(), dayTime.gmtoff);

            for(int i = 0; i < 7; i++){
                JSONObject data = datalist.getJSONObject(i);

                dateTime = dayTime.setJulianDay(julianStartDay+i);
                String day = getReadableDateString(dateTime);

                JSONObject temp = new JSONObject(data.getString("temp"));
                double min = Math.round(temp.getDouble("min")*10)/10.0;
                double max = Math.round(temp.getDouble("max")*10)/10.0;
//                    Log.i("min", min);

                list.add(day + "　 　　　　" + min + "　/　" + max);

            }

            adapter.notifyDataSetChanged();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private String getReadableDateString(long time){
        // Because the API returns a unix timestamp (measured in seconds),
        // it must be converted to milliseconds in order to be converted to valid date.
        SimpleDateFormat shortenedDateFormat = new SimpleDateFormat("YYYY/MM/dd");
        String ee = new SimpleDateFormat("EE").format(time);

        return shortenedDateFormat.format(time);
    }
    class FetchWeatherTask extends AsyncTask<String, Void, String>{
        @Override
        protected String doInBackground(String... address) {
            try{
                URL url = new URL(address[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.connect();

                InputStream is = connection.getInputStream();
                InputStreamReader isr = new InputStreamReader(is);

                int data = isr.read();
                String content = "";

                char c;
                while(data != -1){
                    c = (char) data;
                    content = content + c;
                    data = isr.read();
                }
                return content;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}